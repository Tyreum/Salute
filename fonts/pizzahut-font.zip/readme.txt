PizzaHut Font

This font was created using FontCreator 6.5 from High-Logic.com

This font is trademarked by Pizza Hut.
